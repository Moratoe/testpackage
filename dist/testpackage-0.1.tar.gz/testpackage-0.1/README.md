# mypackage
This library has been created to demonstrate how to create and publish python package

## building this package locally
`python setup.py sdist`

## installing this package from GitHub
`pip install git+"<link>"`

## updating this package from GitHub
`pip install --upgrade git+"<link>"`
